// ==UserScript==
// @name         Chats
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://chat.neural-university.ru/home
// @include        https://chat.neural-university.ru/*
// @icon         https://www.google.com/s2/favicons?domain=neural-university.ru
// @grant        none
// @run-at document-end
// ==/UserScript==

(function() {
        async function GM_addStyle(css) {
  const style = document.getElementById("GM_addStyleBy8626") || (function() {
    const style = document.createElement('style');
    style.type = 'text/css';
    style.id = "GM_addStyleBy8626";
    document.head.appendChild(style);
    return style;
  })();
  const sheet = style.sheet;
  sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
};

    const dimGray = 'dimgrey';
    const regBlack = 'Black';
    const textColor = 'white';
    setTimeout(()=>{
        const allBtns = document.querySelectorAll('.rcx-box.rcx-box--full.rcx-box--animated.rcx-sidebar-item__menu.rcx-button--mini-square.rcx-button--square.rcx-button--ghost.rcx-button.rcx-css-ue04py');
        allBtns.forEach(e=>{
        e.addEventListener('mouseout', ()=>{
        console.log('dasdasdas');
        });
        });

    const curr = document.querySelector('.rc-header');
    GM_addStyle(`button, section, div, span, p, textarea, .rcx-css-dlop43 {
    background-color:${dimGray} !important;
    color:${textColor} !important;
    }`);
        GM_addStyle(`.message.new-day:before, .rcx-tag--secondary {
    background-color:${regBlack};
    }`);
    }, 1000);
})();