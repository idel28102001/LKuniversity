// ==UserScript==
// @name         Chats
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://chat.neural-university.ru/home
// @include        https://chat.neural-university.ru/*
// @icon         https://www.google.com/s2/favicons?domain=neural-university.ru
// @grant        none
// @run-at document-end
// ==/UserScript==

(function() {
        async function GM_addStyle(css) {
  const style = document.getElementById("GM_addStyleBy8626") || (function() {
    const style = document.createElement('style');
    style.type = 'text/css';
    style.id = "GM_addStyleBy8626";
    document.head.appendChild(style);
    return style;
  })();
  const sheet = style.sheet;
  sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
};

    const dimGray = 'dimgrey';
    const regBlack = 'Black';
    const textColor = 'white';
    const btnRegulH = 'grey';
    const anotherGrey = 'darkgrey';
    const btnBlue = 'CornflowerBlue';
    const currNum = 0;
    let currTime = (new Date()).getHours();
    let currTimeText = 'Приветсвую';
    let pureName = 'Коллега';
    let resText = `${currTimeText}, ${pureName}.`;
    const timeDict = {6: 'Доброй ночи',12: 'Доброе утро',18: 'Добрый день',24:'Добрый вечер'};

    GM_addStyle(`.currBtn:hover {
    border: 3px solid ${textColor};
    }`);
        GM_addStyle(`.currBtn:active {
    border: 2px solid ${textColor};
    }`);

        GM_addStyle(`.currBtn {
    box-sizing: border-box;
    transition: border 100ms ease;
    }`);

    GM_addStyle(`button, section, div, span, p, textarea, .rcx-css-dlop43,blockquote .rcx-css-1d5cod7,div .rcx-css-ps0pgs{
    background-color:${dimGray} !important;
    color:${textColor} !important;
    }`);
        GM_addStyle(`.message:hover {
    background-color:${btnRegulH} !important;
    }`);
        GM_addStyle(`.message.new-day:before, .rcx-tag--secondary {
    background-color:${regBlack};
    }`);

    GM_addStyle(`.rcx-sidebar-item__title {
    color:${anotherGrey} !important;
    }`);

               GM_addStyle(`.rcx-sidebar-item__icon--highlighted, .rcx-sidebar-item--highlighted {
    color:${textColor} !important;
    }`);
                   GM_addStyle(`.rcx-sidebar-item:active, .rcx-sidebar-item--selected {
    background-color:${regBlack} !important;
    }`);
                   GM_addStyle(`.message a, div .rcx-css-4wru5q a {
    color: ${btnBlue} !important;
    }`);
                       GM_addStyle(`.rc-popover.rc-popover--message-box, .rc-modal-wrapper {
        background-color: transparent !important;
    }`);
                           GM_addStyle(`.BIG {
        display: inline-block;
        position:fixed;
        font-size: 100px;
        background-color: darkred !important;
        height: 150px;
        z-index: 10000;
        padding: 50px 30px;
        bottom: 500px;
        left: 700px;
        border-radius: 50px;
    }`);
                               GM_addStyle(`.currAAA {
            color: ${btnBlue};
            font-weight: 900;
    }`);

                                   GM_addStyle(`.currEClass:hover {
            border: 2px solid red;
    }`);
                                   GM_addStyle(`.currEClass {
            transition: border 100ms ease-in-out;
    }`);
    setTimeout(()=>{
    const currError = document.querySelector('.toast.toast-error');
        if (currError) {
        currError.remove();
        };

  // const allButtons = document.querySelectorAll('.rcx-avatar__element.rcx-avatar--x16');
     //   allButtons.forEach(e=>{
     //   e.addEventListener('dblclick', ()=>{
      //  console.log('Слово!!!');
      //  })
      //  })

    const curr = document.querySelector('.rc-header');
    }, 1000);

        setInterval(()=>{

   const allButtons = document.querySelectorAll('div.rcx-box.rcx-box--full.rcx-sidebar-item__wrapper div div figure img.rcx-avatar__element.rcx-avatar--x16');
   const allLinks = document.querySelectorAll('a.rc-box.rcx-box--full.rcx-sidebar-item.rcx-sidebar-item--clickable');
        allLinks.forEach(e=>{
        const currLab = e.getAttribute('aria-label');
        const currE = e.children[0].children[0].children[0].children[0].children[0];
        if (!currE.hasAttribute('data-eventList') && currLab.startsWith('question_')) {

            e.addEventListener('click', ()=>{
            setTimeout(()=>{
            console.log(document.querySelector('a[rel="noopener noreferrer"]'));
            let currElement = document.querySelector('.rcx-box.rcx-box--full.rcx-box--with-inline-elements.rcx-css-1te28na');

                const currA = document.createElement('a');
                currA.classList.add('rcx-box','rcx-box--full','rcx-box--with-inline-elements', 'rcx-css-1te28na','currAAA');
                currA.textContent = currElement.textContent;
                currA.href = document.querySelector('a[rel="noopener noreferrer"]').href;
                currElement.parentNode.replaceChild(currA,currElement);

            const currBtn = document.querySelector('img.rcx-avatar__element.rcx-avatar--x36');
            currBtn.classList.add('currBtn');
            currBtn.addEventListener('click',()=>{
            currElement = document.querySelector('.rcx-box.rcx-box--full.rcx-box--with-inline-elements.rcx-css-1te28na');
            if (currElement) {
            let currText = currElement.textContent;
                currText = currText.split('#');
                currText = currText[currText.length-1].split(' ').slice(1).filter(e=>e!=='');
           switch (currText.length) {
           case 1:
               pureName = currText[0];
               break;
           case 2:
           case 3:
               pureName = currText[1];
               break;
       };
                const currDate = new Date();
                currTime = currDate.getHours();
                for (let [time, text] of Object.entries(timeDict)) {
                if (currTime< time) {
                currTimeText = text;
                };
                }

                resText = `${currTimeText}, ${pureName}.)`;
                const currTextArea = document.querySelector('textarea[aria-label="Сообщение"]');
                currTextArea.value = resText;
                currTextArea.focus();
            };
            });
            },300)
            });

            currE.classList.add('currEClass');
        currE.setAttribute('data-eventList','true');
        currE.addEventListener('click', ()=>{
            setTimeout(()=>{
        const currBtnForInfo = document.querySelector(`[data-toolbox="0"]`);
        currBtnForInfo.click();
                setTimeout(()=>{
                    const currEdit = document.querySelector(`[aria-label="Редактировать"]`);
                    currEdit.click();
                    setTimeout(()=>{
                    const currCheckbox = document.querySelectorAll(`.rcx-box.rcx-box--full.rcx-css-zqz844`)[1];
                    currCheckbox.children[1].children[0].click();

                    const currSave = document.querySelector(`button[type="button"].rcx-box.rcx-box--full.rcx-box--animated.rcx-button.rcx-button-group__item.rcx-css-t3n91h`);
                    currSave.click();

                    const currBack = document.querySelector(`button[type="button"].rcx-box.rcx-box--full.rcx-box--animated.rcx-button--tiny-square.rcx-button--square.rcx-button--ghost.rcx-button.rcx-css-x7bl3q.rcx-css-1yzvz7u`);
                    currBack.click();
                        setTimeout(()=>{
                        const currMen = document.querySelector(`button[type="button"].rcx-box.rcx-box--full.rcx-box--animated.rcx-button--square.rcx-button.rcx-button-group__item.rcx-css-1k1r0f9`);
                        currMen.click();

                        setTimeout(()=>{
                        const currMnaa = document.querySelectorAll(`ol[role="listbox"] li`);
                            for (let i = 0; i<3; i++) {
                            currMnaa[i].style.display = 'none';
                            };
                            currMnaa[3].children[0].children[1].classList.add('BIG');
                        }, 200);
                        }, 200);
                    }, 200);
                }, 500);
            }, 100)
        })
        };
        })

    const curr = document.querySelector('.rc-header');
    }, 500);

})();