// ==UserScript==
// @name         Chats
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://chat.neural-university.ru/home
// @include        https://chat.neural-university.ru/*
// @icon         https://www.google.com/s2/favicons?domain=neural-university.ru
// @grant        none
// @run-at document-end
// ==/UserScript==

(function() {
        async function GM_addStyle(css) {
  const style = document.getElementById("GM_addStyleBy8626") || (function() {
    const style = document.createElement('style');
    style.type = 'text/css';
    style.id = "GM_addStyleBy8626";
    document.head.appendChild(style);
    return style;
  })();
  const sheet = style.sheet;
  sheet.insertRule(css, (sheet.rules || sheet.cssRules || []).length);
};

    const dimGray = 'dimgrey';
    const regBlack = 'Black';
    const textColor = 'white';
    const btnRegulH = 'grey';
    const anotherGrey = 'darkgrey';
    const btnBlue = 'CornflowerBlue';
    GM_addStyle(`button, section, div, span, p, textarea, .rcx-css-dlop43,blockquote .rcx-css-1d5cod7,div .rcx-css-ps0pgs{
    background-color:${dimGray} !important;
    color:${textColor} !important;
    }`);
        GM_addStyle(`.message:hover {
    background-color:${btnRegulH} !important;
    }`);
        GM_addStyle(`.message.new-day:before, .rcx-tag--secondary {
    background-color:${regBlack};
    }`);

    GM_addStyle(`.rcx-sidebar-item__title {
    color:${anotherGrey} !important;
    }`);

               GM_addStyle(`.rcx-sidebar-item__icon--highlighted, .rcx-sidebar-item--highlighted {
    color:${textColor} !important;
    }`);
                   GM_addStyle(`.rcx-sidebar-item:active, .rcx-sidebar-item--selected {
    background-color:${regBlack} !important;
    }`);
                   GM_addStyle(`.message a, div .rcx-css-4wru5q a {
    color: ${btnBlue} !important;
    }`);
                       GM_addStyle(`.rc-popover.rc-popover--message-box, .rc-modal-wrapper {
        background-color: transparent !important;
    }`);
    setTimeout(()=>{
    const currError = document.querySelector('.toast.toast-error');
        if (currError) {
        currError.remove();
        };


    const curr = document.querySelector('.rc-header');
    }, 800);
})();